﻿using System.Drawing;

namespace MapLibrary
{
    public class Map
    {

        public int mapwidth;
        public int mapheight;
        public byte[][,] maparray;
		public int layers=1;

		public void SetMap(int width, int height, byte[][,] world, int numberOfLayers)
        {
        	mapwidth=width;
        	mapheight=height;
        	maparray=world;
			layers = numberOfLayers;
        }
        
		public void drawLayer(Graphics g, int width, int height, int offsetx, int offsety, int displayx, int displayy, Bitmap[] tileset, int layerNumber){
			for (int ready = 0; ready <= height; ready++) {
				for (int readx = 0; readx <= width; readx++) {
					if (tileset [maparray [layerNumber] [readx + offsetx, ready + offsety]] != null) {
						g.DrawImage (tileset [maparray [layerNumber] [readx + offsetx, ready + offsety]], readx * 32 + displayx, ready * 32 + displayy);
					}
				}
			}  
		}


		
		public void drawTile(Graphics g, int mapX, int mapY, int displayX, int displayY, Bitmap[] tileset, int layerNumber){
			
			if (tileset [maparray [layerNumber] [mapX,mapY]] != null) {
				//g.DrawImage (tileset[maparray[layerNumber][mapX,mapY]], displayX,displayY);
				g.DrawImage(tileset[maparray[layerNumber] [mapX,mapY]],displayX,displayY);
			}
			
		}

		
		
		public void drawNoErrorCheck(Graphics g, int width, int height, int offsetx, int offsety, int displayx, int displayy, Bitmap[] tileset)
        {
        	for (int i = 0; i < layers; i++) {
				for (int ready = 0; ready <= height; ready++) {
					for (int readx = 0; readx <= width; readx++) {
        					g.DrawImage (tileset [maparray [i] [readx + offsetx, ready + offsety]], (readx * 32 + displayx), (ready * 32 + displayy));
					}
				}
			}
        }
		
        public void draw(Graphics g, int width, int height, int offsetx, int offsety, int displayx, int displayy, Bitmap[] tileset)
        {
        	for (int i = 0; i < layers; i++) {
				for (int ready = 0; ready <= height; ready++) {
					for (int readx = 0; readx <= width; readx++) {
        				if (maparray [i] [readx + offsetx, ready + offsety]>=tileset.Length){continue;}
        				if (tileset [maparray [i] [readx + offsetx, ready + offsety]] != null) {
        					g.DrawImage (tileset [maparray [i] [readx + offsetx, ready + offsety]], (readx * 32 + displayx), (ready * 32 + displayy));
						}
					}
				}
			}
        }

    }
}
