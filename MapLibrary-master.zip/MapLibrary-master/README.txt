Really old and bad code.
The only reason it's here is because it's used in Growtopia Music Simulator Re;born, which isn't abandoned as of writing.