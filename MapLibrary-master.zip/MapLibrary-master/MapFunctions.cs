﻿/*
 * Date: 11/30/2015
 * Time: 12:56 PM
 */

using System;
using System.IO;
using System.Diagnostics;
using System.Drawing;

namespace MapLibrary
{

	public static class MapFunctions
	{
			
		public static Tuple<int,int,byte[][,]> NewMap(int mapWidth, int mapHeight, byte defaultvalue, int numberOfLayers)
            {
			byte[][,] maparray = new byte[numberOfLayers][,];

			for (int i = 0; i < numberOfLayers; i++) {
				maparray [i] = new byte[mapWidth + 1, mapHeight + 1];
				for (int ywrite = 0; ywrite < mapHeight; ywrite++) {
					for (int xwrite = 0; xwrite < mapWidth; xwrite++) {
						maparray[i][xwrite, ywrite] = defaultvalue;
					}
				}
			}

			return Tuple.Create(mapWidth,mapHeight,maparray);
            }
		


		public static Tuple<int,int,int,byte[][,]> LoadMapFromFile(ref FileStream file){
			int mapversion=file.ReadByte();
			int mapWidth=file.ReadByte();
			int mapHeight=file.ReadByte();
			byte past = 255;
			byte present = 254;
			byte rollValue = 55;
			bool rolling = false;
			int rollAmount = 0;
			int layers = file.ReadByte();
			Debug.Print ("layerz:"+layers.ToString ());
			byte[][,] workMap = new byte[layers][,];
			for (int i = 0; i < layers; i++) {
				workMap [i] = new byte[mapWidth + 1, mapHeight + 1];
			}
			//Debug.Print(mapversion.ToString()+";"+mapWidth.ToString()+";"+mapHeight.ToString()+".");
			for (int i = 0; i < layers; i++) {
				for (int y = 0; y < mapHeight; y++) {
					for (int x = 0; x < mapWidth; x++) {
						if (!rolling) {
							if (past == present) {
								// Checked here for good reasons.
								rolling = true;
								rollValue = present;
								rollAmount = file.ReadByte ();
								//Debug.Print("Starting roll with value: "+rollValue.ToString()+" and amount: "+rollAmount.ToString()+".");
								if (rollAmount <= 0) {
									//Debug.Print ("Ending roll...");
									past = 255;
									present = 244;
									rolling = false;
									workMap[i][x, y] = (byte)file.ReadByte();
									past = present;
									present = Convert.ToByte (workMap[i][x, y]);
									//Debug.Print ("Wrote: " + workMap [trueX, trueY].ToString () + " and present and past is: " + present.ToString () + " ; " + past.ToString () + ".");
									continue;
								}
								workMap[i][x, y] = rollValue;
								rollAmount--;
								continue;
							}

							workMap[i][x, y] = (byte)file.ReadByte ();
							past = present;
							present = Convert.ToByte (workMap[i][x, y]);
							//Debug.Print ("Wrote: " + workMap [trueX, trueY].ToString () + " and present and past is: " + present.ToString () + " ; " + past.ToString () + ".");
						} else {
							if (rollAmount <= 0) {
								//Debug.Print ("Ending roll...");
								past = 255;
								present = 244;
								rolling = false;
								workMap[i][x, y] = (byte)file.ReadByte ();
								past = present;
								present = Convert.ToByte (workMap[i][x, y]);
								//Debug.Print ("Wrote: " + workMap [trueX, trueY].ToString () + " and present and past is: " + present.ToString () + " ; " + past.ToString () + ".");
								continue;
							}
							workMap[i][x, y] = rollValue;
							rollAmount--;

						}
					}
				}
			}
			file.Close ();
			file.Dispose ();
			return Tuple.Create (mapWidth, mapHeight,layers, workMap);
		}
			
			
			public static Tuple<int, Bitmap[]> LoadTileset(Bitmap tileset, int tileWidth, int tileHeight){
        	int amountoftiles=(tileset.Width/32);
        	Bitmap[] array = new Bitmap[amountoftiles+1];
        	Rectangle cloneRect = new Rectangle(0, 0, 100, 100);
        	System.Drawing.Imaging.PixelFormat format = tileset.PixelFormat;
        	for (int i=0;i<=amountoftiles-1;i++){
        		cloneRect=new Rectangle(i*32,0,tileWidth,tileHeight);
        		array[i+1]=tileset.Clone(cloneRect, format);
        	}
        	return Tuple.Create(amountoftiles,array);
        }
		
	}
}
 